# Metropolitan Area Network (MAN) using Cisco Packet Tracer

A beginner-friendly BCA Computer Networks mini project demonstrating how three LANs in different locations of a city can communicate through a routed metropolitan network.

## Project overview

This topology contains three campus/branch LANs connected in a line:

`Branch 1 (192.168.10.0/24) -- R1 -- R2 -- R3 -- Branch 3 (192.168.30.0/24)`

Branch 2 (192.168.20.0/24) is connected to R2. Each branch has one router, one 2960 switch and two PCs. Static routes allow communication between all three LANs.

> **Important:** This repository contains the documentation and router CLI configurations. Create and save the actual Cisco Packet Tracer `.pkt` topology in Packet Tracer, then add that file to this repository if your course permits sharing it. A `.pkt` file cannot be replaced by these text configurations.

## Objectives

- Understand the basic concept of a Metropolitan Area Network.
- Connect three separate LANs using routers.
- Configure IPv4 addresses and default gateways.
- Configure static routing between LANs.
- Verify connectivity using `ping`.

## Devices required

| Device | Quantity |
|---|---:|
| Cisco 1941 routers (or compatible routers with serial interfaces) | 3 |
| Cisco 2960 switches | 3 |
| PCs | 6 |
| Serial DCE/DTE links | 2 |
| Copper straight-through links | 6 PC-to-switch + 3 switch-to-router |

If your router model does not have serial interfaces, power it off in Packet Tracer and install a compatible serial module, or adapt the project to Ethernet links.

## Topology

```mermaid
flowchart LR
  subgraph B1["Branch 1 - Main Campus"]
    PC1["PC1<br/>192.168.10.2"]
    PC2["PC2<br/>192.168.10.3"]
    SW1["Switch 1"]
    PC1 --- SW1
    PC2 --- SW1
    SW1 --- R1["Router R1<br/>G0/0: 192.168.10.1"]
  end

  subgraph B2["Branch 2 - City Campus"]
    PC3["PC3<br/>192.168.20.2"]
    PC4["PC4<br/>192.168.20.3"]
    SW2["Switch 2"]
    PC3 --- SW2
    PC4 --- SW2
    SW2 --- R2["Router R2<br/>G0/0: 192.168.20.1"]
  end

  subgraph B3["Branch 3 - Industrial Campus"]
    PC5["PC5<br/>192.168.30.2"]
    PC6["PC6<br/>192.168.30.3"]
    SW3["Switch 3"]
    PC5 --- SW3
    PC6 --- SW3
    SW3 --- R3["Router R3<br/>G0/0: 192.168.30.1"]
  end

  R1 <-->|Serial: 10.0.12.0/30| R2
  R2 <-->|Serial: 10.0.23.0/30| R3
```

## IP addressing plan

### End devices

| Device | IPv4 address | Subnet mask | Default gateway |
|---|---|---|---|
| PC1 | 192.168.10.2 | 255.255.255.0 | 192.168.10.1 |
| PC2 | 192.168.10.3 | 255.255.255.0 | 192.168.10.1 |
| PC3 | 192.168.20.2 | 255.255.255.0 | 192.168.20.1 |
| PC4 | 192.168.20.3 | 255.255.255.0 | 192.168.20.1 |
| PC5 | 192.168.30.2 | 255.255.255.0 | 192.168.30.1 |
| PC6 | 192.168.30.3 | 255.255.255.0 | 192.168.30.1 |

### Router interfaces

| Router | Interface | IPv4 address | Subnet mask |
|---|---|---|---|
| R1 | G0/0 | 192.168.10.1 | 255.255.255.0 |
| R1 | S0/0/0 | 10.0.12.1 | 255.255.255.252 |
| R2 | G0/0 | 192.168.20.1 | 255.255.255.0 |
| R2 | S0/0/0 | 10.0.12.2 | 255.255.255.252 |
| R2 | S0/0/1 | 10.0.23.1 | 255.255.255.252 |
| R3 | G0/0 | 192.168.30.1 | 255.255.255.0 |
| R3 | S0/0/0 | 10.0.23.2 | 255.255.255.252 |

## Build instructions in Cisco Packet Tracer

1. Add three routers, three 2960 switches and six PCs.
2. Connect two PCs to each switch using copper straight-through cables.
3. Connect each switch to its router's `GigabitEthernet0/0` interface.
4. Connect R1 `Serial0/0/0` to R2 `Serial0/0/0`.
5. Connect R2 `Serial0/0/1` to R3 `Serial0/0/0`.
6. If serial ports are missing, power off the router and install a compatible serial interface module, then power it on.
7. Configure each PC using the IP table above: Desktop → IP Configuration → Static.
8. Enter the router configurations from the `configs/` directory.
9. Save the Packet Tracer project as `Metropolitan_Area_Network.pkt`.

Cable/interface names can differ by router model and installed modules. If your device uses different interface names, adapt the commands to the interfaces shown in Packet Tracer.

## Router configuration

The full configurations are in:

- [`configs/R1.txt`](configs/R1.txt)
- [`configs/R2.txt`](configs/R2.txt)
- [`configs/R3.txt`](configs/R3.txt)

**Serial clocking:** Set `clock rate 64000` only on the DCE end of each serial link. Check the cable endpoint in Packet Tracer; if the DCE end is not the interface shown in the sample configuration, move the command to the actual DCE interface.

## Verification

From PC1, open Desktop → Command Prompt and run:

```text
ping 192.168.20.2
ping 192.168.30.2
ping 192.168.30.3
```

Also verify the routers:

```text
show ip interface brief
show ip route
```

Successful ping replies indicate that the tested end-to-end path is working. The first ping may time out while ARP entries are being learned; try it again.

## Expected outcome

All three LANs should be able to communicate with one another after interface addressing, serial links and static routes are configured correctly.

## Troubleshooting

- Check that all used interfaces are enabled with `no shutdown`.
- Confirm PC IP addresses, subnet masks and default gateways.
- Confirm the serial interfaces are connected to the intended ports.
- Confirm the DCE end has a clock rate configured.
- Check that static routes point to the correct next-hop address.
- Use `show ip interface brief` and `show ip route` to identify configuration issues.

## Conclusion

This project demonstrates a basic MAN-style network connecting three geographically separate LANs. It provides practical experience with Cisco Packet Tracer, IPv4 addressing, router interfaces, static routing and connectivity testing.

## Suggested repository contents

```text
Metropolitan_Area_Network_MAN/
├── README.md
├── configs/
│   ├── R1.txt
│   ├── R2.txt
│   └── R3.txt
└── .gitignore
```

Add your completed `.pkt` file and screenshots after building and testing the topology in Packet Tracer.
